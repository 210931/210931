
1. AWS Lambda Power Tuning
    - https://github.com/alexcasalboni/aws-lambda-power-tuning