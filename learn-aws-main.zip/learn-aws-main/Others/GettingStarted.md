
# Getting started with AWS

AWS had been there for quite some time and there are lot of articles around the internet on the same. It's east to get lost. These are the few resources to get started with AWS.

1. AWS Blog.
    - https://aws.amazon.com/blogs/

1. AWS Documentation.
    - https://docs.aws.amazon.com/

1. AWS Official YouTube Channels
    - Amazon Web Services  - https://www.youtube.com/channel/UCd6MoB9NC6uYN2grvUNT-Zg
    - AWS Events - https://www.youtube.com/channel/UCdoadna9HFHsxXWhafhNvKw
    - AWS Online Tech Talks - https://www.youtube.com/channel/UCT-nPlVzJI-ccQXlxjSvJmw

1. Tools to ease information explosion.
    - Pocket - https://getpocket.com/
    - Inoreader - https://www.inoreader.com/