# Free data sets to start working with Big Data on AWS

1. Registry of Open Data on AWS
    - https://registry.opendata.aws/

1. Gnome data
    - https://www.ncbi.nlm.nih.gov/gene/

1. CloudTrail Data
    - https://summitroute.com/blog/2020/10/09/public_dataset_of_cloudtrail_logs_from_flaws_cloud/
    - https://github.com/easttimor/aws-incident-response