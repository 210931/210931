# Prerequisites to get into AWS

1. Basics of Linux
    - https://www.guru99.com/must-know-linux-commands.html

1. Basics of IP Addressing
    - https://medium.com/@sadatnazrul/basics-of-ip-addresses-in-computer-networking-f1a4661ea85c