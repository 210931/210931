
1. What is zero trust identity security?
    - https://cloud.google.com/blog/topics/developers-practitioners/what-zero-trust-identity-security