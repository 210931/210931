
1. Passing the AWS Certified Security-Speciality exam
    - https://rzepsky.medium.com/passing-the-aws-certified-security-speciality-exam-d5ac90b3cdbc
    - https://coggle.it/diagram/XCx0VU8yTIKcn9xF/t/aws-certified-security-specialty