
# General

1. AWS Security Documentation
https://docs.aws.amazon.com/security/

# Blogs

1. AWS Security Blog
    - https://aws.amazon.com/blogs/security/feed

# Open Source Projects

1, Introducing Assisted Log Enabler for AWS
    - https://aws.amazon.com/blogs/opensource/introducing-assisted-log-enabler-for-aws/