
1. CloudGoat is Rhino Security Labs' "Vulnerable by Design" AWS deployment tool
    - https://github.com/RhinoSecurityLabs/cloudgoat

1. Pacu: The Open Source AWS Exploitation Framework
    - https://rhinosecuritylabs.com/aws/pacu-open-source-aws-exploitation-framework/

1. ConsoleMe: A Central Control Plane for AWS Permissions and Access
    - https://netflixtechblog.com/consoleme-a-central-control-plane-for-aws-permissions-and-access-fd09afdd60a8

1. Netflix Cloud Security: Detecting Credential Compromise in AWS
    - https://netflixtechblog.com/netflix-cloud-security-detecting-credential-compromise-in-aws-9493d6fd373a
    - https://netflixtechblog.com/netflix-information-security-preventing-credential-compromise-in-aws-41b112c15179

1. Building Netflix’s Distributed Tracing Infrastructure
    - https://netflixtechblog.com/building-netflixs-distributed-tracing-infrastructure-bb856c319304

1. AquaSecurity/cloudsploit
    - https://github.com/aquasecurity/cloudsploit