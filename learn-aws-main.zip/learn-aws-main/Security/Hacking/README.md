
1. S3 Ransomware
	- https://rhinosecuritylabs.com/aws/s3-ransomware-part-1-attack-vector/
	- https://rhinosecuritylabs.com/aws/s3-ransomware-part-2-prevention-and-defense/

1. Phishing Users with MFA on AWS
	- https://rhinosecuritylabs.com/aws/mfa-phishing-on-aws/

1. Abusing VPC Traffic Mirroring in AWS
    - https://rhinosecuritylabs.com/aws/abusing-vpc-traffic-mirroring-in-aws/