
1. Hands-On AWS Penetration Testing with Kali Linux
    - https://www.amazon.in/Hands-Penetration-Testing-Kali-Linux/dp/1789136725/

1. AWS Penetration Testing: Beginner's guide to hacking AWS with tools such as Kali Linux, Metasploit, and Nmap
    - https://www.amazon.in/AWS-Penetration-Testing-Beginners-Metasploit/dp/1839216921/

1. Practical Cloud Security: A Guide for Secure Design and Deployment
    - https://www.amazon.in/Practical-Cloud-Security-Secure-Deployment/dp/9352138155/