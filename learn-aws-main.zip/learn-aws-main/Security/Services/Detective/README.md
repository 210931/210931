# Detective

# Further Reading

1. Investigate VPC flow with Amazon Detective
    - https://aws.amazon.com/blogs/security/investigate-vpc-flow-with-amazon-detective/