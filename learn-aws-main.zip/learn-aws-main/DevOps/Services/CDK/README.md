
# Further Reading

1. CDK Workshop
    - https://cdkworkshop.com/

1. Official examples
    - https://github.com/aws-samples/aws-cdk-examples

1. Constructs (building blocks)
    - https://docs.aws.amazon.com/cdk/latest/guide/constructs.html