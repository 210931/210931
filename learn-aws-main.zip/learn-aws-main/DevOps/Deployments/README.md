
1. ECS Deployment Options - From rolling updates to blue-green and canary
    - https://cloudonaut.io/ecs-deployment-options/