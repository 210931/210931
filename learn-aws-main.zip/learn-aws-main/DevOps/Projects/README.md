
1. Chaos Testing with AWS Fault Injection Simulator and AWS CodePipeline
    - https://aws.amazon.com/blogs/architecture/chaos-testing-with-aws-fault-injection-simulator-and-aws-codepipeline/

1. Increase your e-commerce website reliability using chaos engineering and AWS Fault Injection Simulator
    - https://aws.amazon.com/blogs/devops/increase-e-commerce-reliability-using-chaos-engineering-with-aws-fault-injection-simulator/