
1. A fully functional local cloud stack (Develop and test your cloud and serverless apps offline!)
    - https://localstack.cloud/
