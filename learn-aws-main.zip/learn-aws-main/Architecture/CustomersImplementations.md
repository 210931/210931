
# General

1. This is my Architecture
    - https://www.youtube.com/playlist?list=PLhr1KZpdzukdeX8mQ2qO73bg6UKQHYsHb

# Amazon

1. How Amazon builds and operates software
    - https://aws.amazon.com/builders-library/

# Hotstar

1. Scaling hotstar.com for 25 million concurrent viewers
    - https://www.youtube.com/watch?v=QjvyiyH4rr0
    - https://docs.google.com/presentation/d/1IYLsySe_thA6qeztnL4Tmhszdu2Wd5-3CKKLm26m-9Y/edit?usp=sharing (Slides for above)
    - https://www.youtube.com/watch?v=2qYR78U4eNQ

# Netflix

1. How Netflix is able to enrich VPC Flow Logs at Hyper Scale to provide Network Insight
    - https://netflixtechblog.com/hyper-scale-vpc-flow-logs-enrichment-to-provide-network-insight-e5f1db02910d