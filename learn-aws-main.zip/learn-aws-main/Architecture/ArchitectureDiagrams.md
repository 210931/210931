# Architecture and Diagrams

Architecture diagrams helps us to convey the concepts better.

1. AWS Perspective Solution
    - https://aws.amazon.com/about-aws/whats-new/2020/09/introducing-aws-perspective/
    - https://aws.amazon.com/solutions/implementations/aws-perspective/

1. 3rd party solutions
    - https://cloudcraft.co/
    - https://app.diagrams.net/

1. Freehand AWS Diagrams
    - https://www.awsgeek.com/