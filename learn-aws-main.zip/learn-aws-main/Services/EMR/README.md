
# Further Reading

1. Announcing Amazon EMR Serverless (Preview): Run big data applications without managing servers
    - https://aws.amazon.com/blogs/big-data/announcing-amazon-emr-serverless-preview-run-big-data-applications-without-managing-servers/