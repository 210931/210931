# Costing

![](images/2021-04-21-17-59-55.png)

# Further Reading

1. How to Monitor and Manage Your AWS Costs - AWS Online Tech Talks
    - https://www.youtube.com/watch?v=pjrKDkzbas8

1. Activating User-Defined Cost Allocation Tags
    - https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/activating-tags.html