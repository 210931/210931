
# Further Reading

1. SNS Success/Failure Handling
    - https://docs.aws.amazon.com/sns/latest/dg/sns-topic-attributes.html
    - https://aws.amazon.com/premiumsupport/knowledge-center/troubleshoot-failed-sns-deliveries/