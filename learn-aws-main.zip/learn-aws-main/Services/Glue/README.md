
1. What is AWS Glue? A Detailed Introductory Guide
    - https://www.lastweekinaws.com/blog/what-is-aws-glue-a-detailed-introductory-guide/