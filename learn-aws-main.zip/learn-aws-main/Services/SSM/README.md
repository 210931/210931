
1. Running Commands Using AWS Systems Manager: A Step-by-Step Guide
    - https://blog.cloudthat.com/runnung-commands-using-aws-systems-manager-a-step-by-step-guide/