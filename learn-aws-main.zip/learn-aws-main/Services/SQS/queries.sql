/*
Create an RDS MySQL Instance and create a customers table in it
*/

CREATE TABLE customers (
  name VARCHAR(30) NOT NULL,
  address VARCHAR(30) NOT NULL
);