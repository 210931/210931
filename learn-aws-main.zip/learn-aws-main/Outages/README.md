
1. Timeline of all the AWS outages
    - https://en.wikipedia.org/wiki/Timeline_of_Amazon_Web_Services#Amazon_Web_Services_outages
    - https://awsmaniac.com/aws-outages/

1. Amazon blames generator-stabilization issue for outage
    - https://aws.amazon.com/message/67457/
    - https://www.datacenterdynamics.com/en/news/amazon-blames-generator-stabilization-issue-for-outage/