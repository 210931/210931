# This is a list of all the projects and applications related to Migration.

1. Populating your graph in Amazon Neptune from a relational database using AWS Database Migration Service (DMS)
    - https://aws.amazon.com/blogs/database/populating-your-graph-in-amazon-neptune-from-a-relational-database-using-aws-database-migration-service-dms-part-1-setting-the-stage/