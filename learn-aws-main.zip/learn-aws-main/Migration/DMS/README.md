
# Further Reading

1. AWS Database Migration Service (DMS)
    - https://www.youtube.com/watch?v=zb4GcjEdl8U